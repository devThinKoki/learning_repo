# Section01
# 파이썬 소개 및 작업 환경 설정

#기본 출력
print('Hello Python!')